﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Authentication.ExtendedProtection;
using UnityEngine;

public class Hacker : MonoBehaviour
{ 
   private int level;
   private enum Screen { Mainmenu, Password, Win };
    private Screen CurrentScreen;

    // Start is called before the first frame update
    void Start()
    {
        ShowMainMenu();
    }

    void ShowMainMenu()
    {
        CurrentScreen = Screen.Mainmenu;
        Terminal.ClearScreen();
        Terminal.WriteLine("Welcome to TERMINAL,");
        Terminal.WriteLine("What would you like to hack today?");
        Terminal.WriteLine("1. Police DATABASE");
        Terminal.WriteLine("2. Central Bureau of Investigation");
        Terminal.WriteLine("3. Military DATABASE");
    }
    void OnUserInput(string input)
    { 
        if (input == "menu")
        {
            Start();
        }
        else if (CurrentScreen == Screen.Mainmenu)
        {
            RunMainMenu(input);
        } 
    }

     void RunMainMenu(string input)
    {
        if (input == "1")
        {
            level = 1;
            StartGame();
        }
        else if (input == "2")
        {
            level = 2;
            StartGame();
        }
        else if (input == "3")
        {
            level = 3;
            StartGame();
        }
        else if (input == "Voldemort")
        {
            Terminal.WriteLine("Bring me Harry Potter!!");
        }
        else
        {
            Terminal.WriteLine("Choose valid Option");
        }
    }

    void StartGame()
    {
        CurrentScreen = Screen.Password;
        Terminal.WriteLine("You have chosen: " + level);
        Terminal.WriteLine("Enter your password");
    }
}
