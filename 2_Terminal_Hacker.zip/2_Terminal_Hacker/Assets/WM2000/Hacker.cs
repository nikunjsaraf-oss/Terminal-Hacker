﻿using UnityEngine;

public class Hacker : MonoBehaviour
{
    private string menuhint = "Type 'menu' to go back";
    private int level;
    private enum Screen { Mainmenu, Password, Win };
    private Screen CurrentScreen;
    private string password = "";
    private string[] level1Passwords = { "stop", "tar", "night", "yap", "ape"};
    private string[] level2Passwords = { "soils", "solo", "Rome", "Las Vegas", "Madison"};
    private string[] level3Passwords = { "Old England", "Valentine Poem", "Gold and Silver", "an Aisle", "Dynamite" };
    // Start is called before the first frame update
    void Start()
    {
        ShowMainMenu();
    }

    void ShowMainMenu()
    {
        CurrentScreen = Screen.Mainmenu;
        Terminal.ClearScreen();
        Terminal.WriteLine("Welcome to TERMINAL,");
        Terminal.WriteLine("What would you like to hack today?");
        Terminal.WriteLine("1. Police DATABASE");
        Terminal.WriteLine("2. Federal Bureau of Investigation");
        Terminal.WriteLine("3. Military DATABASE");
    }
    void OnUserInput(string input)
    {
        if (input == "menu")
        {
            Start();
        }
        else if (CurrentScreen == Screen.Mainmenu)
        {
            RunMainMenu(input);
        }
        else if (CurrentScreen == Screen.Password)
        {
            CheckPassword(input);
        }
    }

    void RunMainMenu(string input)
    {
        bool isValidLevel = (input == "1" || input == "2" || input == "3");
        if (isValidLevel)
        {
            level = int.Parse(input);
            AskForPassword();
        }
        else if (input == "Voldemort")
        {
            Terminal.WriteLine("Bring me Harry Potter!!");
        }
        else
        {
            Terminal.WriteLine("Choose valid Option");
        }
    }

    void AskForPassword()
    {
        CurrentScreen = Screen.Password;
        Terminal.ClearScreen();
        switch(level)
        {
            case 1:
                password = level1Passwords[Random.Range(0, 5)];
                break;
            case 2:
                password = level2Passwords[Random.Range(0, 5)];
                break;
            case 3:
                password = level3Passwords[Random.Range(0, 5)];
                break;
            default:
               Debug.LogError("Invalid Level Number");
               break;
        }
        Terminal.WriteLine("Enter your password. Hint:" + password.Anagram());
        Terminal.WriteLine(menuhint);
    }
    private void CheckPassword(string input)
    {
       if (input == password)
        {
            WinScreen();
        }
        else
        {
            Terminal.WriteLine("Wrong Password");
            AskForPassword();
        }
    }

    void WinScreen()
    {
        Terminal.ClearScreen();
        CurrentScreen = Screen.Win;
        Reward();
        Terminal.WriteLine(menuhint);
    }

    void Reward()
    {
        switch(level)
        {
            case 1:
                Terminal.WriteLine("Welcome back Officer!");
                Terminal.WriteLine(@"

     *_ ....iiooiioo
 __/_|_\__ 
[(o)_R_(o)]
 "                                 );
                Terminal.WriteLine("PLAY AGAIN FOR A NEW CHALLENGE");
                break;
            case 2:
                Terminal.WriteLine("Weclome back Special Officer!");
                Terminal.WriteLine(@"
 __ _     _ 
 / _| |   (_)
| |_| |__  _ 
|  _| '_ \| |
| | | |_) | |
|_| |_.__/|_|
                                   ");
                break;
            case 3:
                Terminal.WriteLine("Welcome Back Major");
                Terminal.WriteLine(@"
          _ _ _ _                   
          (_) (_) |                  
 _ __ ___  _| |_| |_ __ _ _ __ _   _ 
| '_ ` _ \| | | | __/ _` | '__| | | |
| | | | | | | | | || (_| | |  | |_| |
|_| |_| |_|_|_|_|\__\__,_|_|   \__, |
                                __/ |
                               |___/ 
                                    ");
                break;
            default:
                Debug.LogError("Error");
                break;
        }
    }
}
